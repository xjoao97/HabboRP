﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plus.HabboHotel.Users.Messenger
{
    public enum MessengerMessageErrors
    {
        FRIEND_MUTED,
        YOUR_MUTED,
        FRIEND_NOT_ONLINE,
        YOUR_NOT_FRIENDS,
        FRIEND_BUSY,
        OFFLINE_FAILED
    }
}
